'''
Created on Oct 16, 2016

@author: HermanSun
'''
# this lab is too hard for Me